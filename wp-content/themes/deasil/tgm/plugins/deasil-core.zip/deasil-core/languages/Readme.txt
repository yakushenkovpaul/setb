Save mo, po file as

for french eg:
deasil-core-fr_FR.mo
deasil-core-fr_FR.po


Now you need to generate .mo files inside theme forlder deasil > languages and plugin folder deasil-core > languages
Please Read: https://ulrich.pogson.ch/load-theme-plugin-translations